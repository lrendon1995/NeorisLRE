﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace NeorisLRE.DA
{
    public class DbHelper
    {
        private SqlConnection Conn { get; }

        private SqlTransaction Trx { get; set; }

        private bool EnTransaccion => Trx != null;

        private string ConnectionString => ConfigurationManager.ConnectionStrings["SisBDConnString"].ConnectionString;

        public DbHelper()
        {
            if (Conn == null)
            {
                Conn = new SqlConnection(ConnectionString);
            }
        }

        public DbHelper(string connectionString)
        {
            Conn = new SqlConnection(connectionString);
        }

        public void IniciarTransaccion()
        {
            if (Trx != null) return;
            Conn.Open();
            Trx = Conn.BeginTransaction();
        }

        public void ConfirmarTransaccion()
        {
            if (Trx != null)
            {
                Trx.Commit();
                Trx = null;
                Conn.Close();
            }
        }

        public void AbortarTransaccion()
        {
            if (Trx == null) return;
            Trx.Rollback();
            Trx = null;
            Conn.Close();
        }

        public void EjecutarSp(string spName, Hashtable parametros)
        {
            using (var comando = new SqlCommand(spName, Conn))
            {
                if (EnTransaccion)
                {
                    comando.Transaction = Trx;
                }

                comando.CommandType = CommandType.StoredProcedure;
                comando.CommandTimeout = 1200;
                foreach (var o in parametros.Keys)
                {
                    comando.Parameters.AddWithValue(o.ToString(), parametros[o]);
                }

                comando.ExecuteNonQuery();
            }
        }

        public DataSet ConsultarSp(string spName, Hashtable parametros)
        {
            using (var adapter = new SqlDataAdapter(spName, Conn))
            {
                if (EnTransaccion)
                {
                    adapter.SelectCommand.Transaction = Trx;
                }

                adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

                foreach (var o in parametros.Keys)
                {
                    adapter.SelectCommand.Parameters.AddWithValue(o.ToString(), parametros[o]);
                }

                var ds = new DataSet();
                adapter.Fill(ds);
                return ds;
            }
        }

        public DataSet ConsultarSp(string spName, Hashtable parametros, string[] tablas)
        {
            using (var adapter = new SqlDataAdapter(spName, Conn))
            {
                if (EnTransaccion)
                {
                    adapter.SelectCommand.Transaction = Trx;
                }

                adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                foreach (var o in parametros.Keys)
                {
                    adapter.SelectCommand.Parameters.AddWithValue(o.ToString(), parametros[o]);
                }

                var ds = new DataSet();

                adapter.Fill(ds);

                for (var i = 0; i < ds.Tables.Count; i++)
                {
                    ds.Tables[i].TableName = tablas[i];
                }

                return ds;
            }
        }

        /// <summary>
        /// Metodo que devuelve el valor de la primera columna y la primera fila del resultado del SP. Usado generalmente para 
        /// las inserciones donde se necesita que se devuelva el ID generado por la tabla.
        /// </summary>
        /// <param name="spName">Nombre del SP a ejecutar</param>
        /// <param name="parametros">Parametros del SP</param>
        /// <returns>Valor devuelto por el SP</returns>
        public object EjecutarSpEscalar(string spName, Hashtable parametros)
        {
            using (var comando = new SqlCommand(spName, Conn))
            {
                if (EnTransaccion)
                {
                    comando.Transaction = Trx;
                }

                comando.CommandType = CommandType.StoredProcedure;
                comando.CommandTimeout = 1200;
                foreach (var o in parametros.Keys)
                {
                    comando.Parameters.AddWithValue(o.ToString(), parametros[o]);
                }

                return comando.ExecuteScalar();
            }
        }

        public DataTable ConsultarSpDataTable(string spName, Hashtable parametros)
        {
            try
            {
                using (var adapter = new SqlDataAdapter(spName, Conn))
                {
                    if (!EnTransaccion)
                    {
                        Conn.Open();
                    }
                    else
                    {
                        adapter.SelectCommand.Transaction = Trx;
                    }
                    adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                    foreach (var o in parametros.Keys)
                    {
                        adapter.SelectCommand.Parameters.AddWithValue(o.ToString(), parametros[o]);
                    }

                    var dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
            finally
            {
                if (!EnTransaccion) Conn?.Close();
            }
        }

        /// <summary>
        /// Metodo para ejecutar SPs de Consulta.
        /// </summary>
        /// <typeparam name="T">Tipo de Objeto que se desea mapear en el resultado devuelto de la BD</typeparam>
        /// <param name="spName">Nombre del SP a ejecutar</param>
        /// <param name="parametros">Parametros del SP</param>
        /// <returns>Lista de Objetos del Tipo que se desea Mapear</returns>
        public List<T> ConsultarSpReader<T>(string spName, Hashtable parametros)
        {
            try
            {
                using (var comando = new SqlCommand(spName, Conn))
                {
                    if (!EnTransaccion)
                    {
                        Conn.Open();
                    }
                    else
                    {
                        comando.Transaction = Trx;
                    }
                    var lista = new List<T>();
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandTimeout = 15000;
                    if (parametros != null)
                        foreach (var o in parametros.Keys)
                            comando.Parameters.AddWithValue(o.ToString(), parametros[o]);

                    var rd = comando.ExecuteReader();
                    bool a = rd.HasRows;
                    Console.WriteLine(a);
                    if (!rd.HasRows)
                    {
                        rd.Close();
                        return lista;
                    }
                    var propiedades = typeof(T).GetProperties();
                    var hashPropiedades = new Hashtable();
                    foreach (var i in propiedades)
                    {
                        hashPropiedades[i.Name.ToUpper()] = i;
                    }

                    while (rd.Read())
                    {
                        var item = Activator.CreateInstance<T>();
                        for (var i = 0; i < rd.FieldCount; i++)
                        {
                            var info = (PropertyInfo)hashPropiedades[rd.GetName(i).ToUpper()];
                            if (info != null && info.CanWrite)
                            {
                                if (!rd.IsDBNull(i))
                                    info.SetValue(item, rd.GetValue(i), null);
                            }
                        }
                        lista.Add(item);
                    }
                    rd.Close();
                    return lista;
                }
            }
            finally
            {
                if (!EnTransaccion) Conn.Close();
            }
        }
    }
}
