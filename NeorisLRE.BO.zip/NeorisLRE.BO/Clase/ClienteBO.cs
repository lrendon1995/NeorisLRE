﻿using NeorisLRE.BO.Interfaces;
using NeorisLRE.DA;
using NeorisLRE.DTO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeorisLRE.BO.Clase
{
    public class ClienteBO : ICliente
    {
        public DbHelper Helper { get; set; }

        public void GrabarCliente(ClienteDTO cliente)
        {
            var sqlParams = new Hashtable
            {
                {"@idCliente",cliente.IdCliente},
                {"@idPersona" ,cliente.IdPersona},
                {"@nombreCliente" ,cliente.Cliente},
                {"@estado" ,cliente.Estado},
                {"@fechaIng" ,DateTime.Today.ToString("dd-MMM-yyyy")}
            };
            Helper.EjecutarSp("spNeorisInsCliente", sqlParams);
        }
        public void ActualizarCliente(ClienteDTO cliente)
        {
            var sqlParams = new Hashtable
            {
                {"@idCliente",cliente.IdCliente},
                {"@idPersona" ,cliente.IdPersona},
                {"@nombreCliente" ,cliente.Cliente},
                {"@estado" ,cliente.Estado},
                {"@fechaUpd" ,DateTime.Today.ToString("dd-MMM-yyyy")}
            };
            Helper.EjecutarSp("spNeorisUpdCliente", sqlParams);
        }
        public void EliminarCliente(int idCliente, int idPersona)
        {
            var sqlParams = new Hashtable
            {
                {"@idCliente",idCliente},
                {"@idPersona" ,idPersona}
            };
            Helper.EjecutarSp("spNeorisDelCliente", sqlParams);
        }

        public List<ClienteDTO> ConsultarCliente(string cliente)
        {
            var sqlParams = new Hashtable
            {
                {"@cliente", cliente}
            };
            return Helper.ConsultarSpReader<ClienteDTO>("spNeorisConsCliente", sqlParams);
        }

    }
}
