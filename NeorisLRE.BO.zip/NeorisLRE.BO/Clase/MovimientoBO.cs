﻿using NeorisLRE.BO.Interfaces;
using NeorisLRE.DA;
using NeorisLRE.DTO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeorisLRE.BO.Clase
{
    public class MovimientoBO : IMovimiento
    {
        public DbHelper Helper { get; set; }

        public List<MovimientoDTO> ConsultarMovimientos(string codCliente)
        {
            var sqlParams = new Hashtable
            {
                {"@idCliente", codCliente}
            };
            return Helper.ConsultarSpReader<MovimientoDTO>("spNeorisConsMovimiento", sqlParams);
        }

        public void GrabarMovimiento(MovimientoDTO movi)
        {
            var sqlParams = new Hashtable
            {
                {"@idMovimiento",movi.IdMovimiento},
                {"@fecha" ,movi.Fecha},
                {"@tipoMov" ,movi.IdTipoMovimiento},
                {"@valor" ,movi.Valor},
                {"@Saldo" ,movi.Saldo}
            };
            Helper.EjecutarSp("spNeorisInsMovimiento", sqlParams);
        }
    }
}
