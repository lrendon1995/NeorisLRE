﻿using NeorisLRE.DA;
using NeorisLRE.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeorisLRE.BO.Interfaces
{
    public interface ICliente
    {
        DbHelper Helper { get; set; }

        void GrabarCliente(ClienteDTO cliente);
        void ActualizarCliente(ClienteDTO cliente);
        void EliminarCliente(int idCliente, int idPersona);
        List<ClienteDTO> ConsultarCliente(string cliente);
    }
}
