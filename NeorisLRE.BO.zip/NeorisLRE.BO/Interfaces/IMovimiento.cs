﻿using NeorisLRE.DA;
using NeorisLRE.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeorisLRE.BO.Interfaces
{
    public interface IMovimiento
    {
        DbHelper Helper { get; set; }

        void GrabarMovimiento(MovimientoDTO cliente);

        List<MovimientoDTO> ConsultarMovimientos(string codCliente);
    }
}
