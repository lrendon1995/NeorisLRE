﻿using NeorisLRE.BO.Clase;
using NeorisLRE.BO.Operador;
using NeorisLRE.DA;
using NeorisLRE.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeorisLRE.BO.Cliente
{
    public class MovimientoEntidad
    {
        private static DbHelper Helper { get => new DbHelper(); }
        private static OperadorMovimiento OperadorMovimiento
        {
            get
            {
                return new OperadorMovimiento
                {
                    Helper = Helper,
                    Movimiento = new MovimientoBO()
                };
            }
        }

        public static string GrabarMovimiento(MovimientoDTO mov)
        {
            var _operadorMov = OperadorMovimiento;
            return _operadorMov.GrabarMovimiento(mov);
        }

        public static List<MovimientoDTO> ConsultarMovimiento(string codCliente)
        {
            var operador = OperadorMovimiento;
            return operador.ConsultarMovimientoe(codCliente);
        }
    }
}
