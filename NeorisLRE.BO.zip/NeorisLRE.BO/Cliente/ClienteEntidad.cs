﻿using NeorisLRE.BO.Clase;
using NeorisLRE.BO.Operador;
using NeorisLRE.DA;
using NeorisLRE.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeorisLRE.BO.Cliente
{
    public class ClienteEntidad
    {
        private static DbHelper Helper { get => new DbHelper(); }
        private static OperadorCliente OperadorCliente
        {
            get
            {
                return new OperadorCliente
                {
                    Helper = Helper,
                    Cliente = new ClienteBO()
                };
            }
        }

        public static string GrabarCliente(ClienteDTO Cliente)
        {
            var _operadorCliente = OperadorCliente;
            return _operadorCliente.GrabarCliente(Cliente);
        }
        public static string EliminarCliente(int idCliente, int idPersona)
        {
            var _operadorCliente = OperadorCliente;
            return _operadorCliente.EliminaCliente(idCliente,idPersona);
        }
        public static string ActualizarCliente(ClienteDTO Cliente)
        {
            var _operadorCliente = OperadorCliente;
            return _operadorCliente.ActualizaCliente(Cliente);
        }
        public static List<ClienteDTO> ConsultarCliente(string cliente)
        {
            var operador = OperadorCliente;
            return operador.ConsultarCliente(cliente);
        }

    }
}
