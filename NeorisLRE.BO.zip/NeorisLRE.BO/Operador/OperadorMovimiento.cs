﻿using NeorisLRE.BO.Interfaces;
using NeorisLRE.DA;
using NeorisLRE.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeorisLRE.BO.Operador
{
    public class OperadorMovimiento
    {
        public DbHelper Helper { get; set; }
        public IMovimiento Movimiento{ get; set; }
        public string respuesta { get; set; }

        internal string GrabarMovimiento(MovimientoDTO MOV)
        {
            try
            {
                Helper.IniciarTransaccion();
                Movimiento.Helper = Helper;

                if (ConsultarMovimientoe(MOV.IdCliente.ToString()).FirstOrDefault().Saldo <= 0.00)
                {
                    throw new Exception("Saldo No disponible");
                }
                else
                {

                    Movimiento.GrabarMovimiento(MOV);

                };

                Helper.ConfirmarTransaccion();
                respuesta = "Operacion éxitosa";
            }
            catch (Exception ex)
            {
                Helper.AbortarTransaccion();
                respuesta = ex.Message;
            }
            return respuesta;
        }

        internal List<MovimientoDTO> ConsultarMovimientoe(string cliente)
        {
            try
            {
                Movimiento.Helper = Helper;
                return Movimiento.ConsultarMovimientos(cliente);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
