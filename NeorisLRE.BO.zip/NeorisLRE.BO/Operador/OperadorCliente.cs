﻿using NeorisLRE.BO.Interfaces;
using NeorisLRE.DA;
using NeorisLRE.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeorisLRE.BO.Operador
{
    public class OperadorCliente
    {
        public DbHelper Helper { get; set; }
        public ICliente Cliente { get; set; }
        public string respuesta { get; set; }

        internal string GrabarCliente(ClienteDTO cliente)
        {
            
            try
            {
                Helper.IniciarTransaccion();
                Cliente.Helper = Helper;
                Cliente.GrabarCliente(cliente);
                Helper.ConfirmarTransaccion();
                respuesta = "Operacion éxitosa";
            }
            catch (Exception ex)
            {
                Helper.AbortarTransaccion();
                respuesta = ex.Message;
            }
            return respuesta;
        }
        internal string EliminaCliente(int idCliente, int idPersona)
        {
            try
            {
                Helper.IniciarTransaccion();
                Cliente.Helper = Helper;
                Cliente.EliminarCliente(idCliente,idPersona);
                Helper.ConfirmarTransaccion();
                respuesta = "Operacion éxitosa";
            }
            catch (Exception ex)
            {
                Helper.AbortarTransaccion();
                respuesta = ex.Message;
            }
            return respuesta;
        }
        internal string ActualizaCliente(ClienteDTO cliente)
        {
            try
            {
                Helper.IniciarTransaccion();
                Cliente.Helper = Helper;
                Cliente.ActualizarCliente(cliente);
                Helper.ConfirmarTransaccion();
                respuesta = "Operacion éxitosa";
            }
            catch (Exception ex)
            {
                Helper.AbortarTransaccion();
                respuesta = ex.Message;
            }
            return respuesta;
        }
        internal List<ClienteDTO> ConsultarCliente(string cliente)
        {
            try
            {
                Cliente.Helper = Helper;
                return Cliente.ConsultarCliente(cliente);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
