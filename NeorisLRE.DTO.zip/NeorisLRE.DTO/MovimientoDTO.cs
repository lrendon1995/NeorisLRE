﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace NeorisLRE.DTO
{
    [DataContract]
    public class MovimientoDTO
    {
        [DataMember]
        public int IdMovimiento { get; set; }
        [DataMember]
        public DateTime Fecha { get; set; }
        [DataMember]
        public short IdTipoMovimiento { get; set; }
        [DataMember]
        public double Valor { get; set; }
        [DataMember]
        public double Saldo { get; set; }
        [DataMember]
        public short IdCliente { get; set; }
    }
}
